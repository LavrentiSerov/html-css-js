var phoneboxnotationview = 1;

var nxMain = {
    hideScene: !1,
    flashmsgs: !0,
    activity_timer: 0,
    busyagents: 0,
    busyagents_interval: 7e3,
    autoRefresh: !0,
    debug: !1,
    lastTerm: "",
    agentListTimer: 0,
    agentListTimerRefreshInterval: 4e4,
    agentListFilters: {
        id_category: 0,
        media: [],
        term: "",
        term_novalue: "",
        orderby: "",
        filterby: "",
        page: 1
    },
    translate: {
        subscribe1: "Veuillez saisir votre numéro de téléphone.",
        subscribe2: "Veuillez renseigner l'indicatif pays de votre numéro de téléphone."
    },
    nxPopup: 0,
    initSubscription: function() {
        var t = $("#UserSubscribeForm");
        t.submit(function() {
            return "" != t.find("#UserPhoneNumber").val() && "" == t.find("#UserIndicatifPhone").val() ? (alert(nxMain.translate.subscribe2), !1) : "" == t.find("#UserPhoneNumber").val() && "" != t.find("#UserIndicatifPhone").val() ? (alert(nxMain.translate.subscribe1), !1) : !0
        })
    },
    getURLParameter: function(t) {
        for (var i = window.location.search.substring(1), e = i.split("&"), n = 0; n < e.length; n++) {
            var a = e[n].split("=");
            if (a[0] == t) return a[1]
        }
        return !1
    },
    tooltipShow: function(t) {
        t.tooltip("show"), nxMain.tooltipHide(t)
    },
    tooltipHide: function(t) {
        clearTimeout(nxMain.tt_timer), nxMain.tt_timer = setTimeout(function() {
            $(".hover_tooltip").tooltip("hide")
        }, 2500)
    },
    init: function() {
        this.initSubscription(), $(".nxselect").each(function() {
            nxMain.nxSelectify($(this))
        }), $(".table_products").click(function() {
            $(".hover_tooltip").tooltip({
                trigger: "manual"
            }).on("click", nxMain.tooltipShow($(".hover_tooltip")))
        }), this.initModals(), this.initMenu(), this.initAgentListFilters(), this.initCategorySearch(), nx_chat.hasSession(), this.initChat(), this.initEmail(), this.initPhone(), this.initProductsLogin(), this.initActivity(), this.debug && this.initDebug(), this.initFlashMsg();
        var t = this.getURLParameter("filter");
        t && ("chat" == t ? $("label[for=sf_media_chat]").click() : "phone" == t ? $("label[for=sf_media_phone]").click() : "email" == t && $("label[for=sf_media_email]").click())
    },
    initFlashMsg: function() {
        if (!this.flashmsgs) return !1;
        var t = $("div.alert");
        if (t.length) {
            t.find(".close").remove();
            var i = t.html(),
                e = t.attr("class");
            t.remove(), $("body").append('<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title" id="myModalLabel"><img src="' + t.attr("data-logo") + '" alt="' + t.attr("data-site") + '" title="' + t.attr("data-site") + '" style="height: 35px !important; margin-right: 10px;">  </h4></div><div class="modal-body"><div class="' + e + '" style="font-size:16px; margin:0">' + i + "</div><div></div>"), $("#myModal").modal({
                backdrop: !0,
                keyboard: !0,
                show: !0
            })
        }
    },
    hideCmsSubScene: function() {
        $("#cms_container").hide(), this.hideScene = !0
    },
    hideCmsCategory: function() {
        $("#cat_category").hide(), this.hideScene = !0
    },
    initActivity: function() {
        nxMain.activity_timer = setTimeout(function() {
            nxMain.iA_refreshAgentsCounter(); nxMain.iA_refreshAgentsPhoneBox();
        }, nxMain.busyagents_interval)
    },
    iA_refreshAgentsCounter: function() {
        nxMain.ajaxRequest("/home/ajaxactivity", {}, function(t) {
            nxMain.busyagents != t.busy_agents && ($("#box_subscribe span.txt_orange").html(t.busy_agents), nxMain.busyagents = t.busy_agents), nxMain.activity_timer = setTimeout(function() {
                nxMain.iA_refreshAgentsCounter();nxMain.iA_refreshAgentsPhoneBox();
            }, nxMain.busyagents_interval)
        })
    },
	iA_refreshAgentsPhoneBox: function() {
        nxMain.ajaxRequest("/phones/hassession", {}, function(t) {
			if($('.phonebox').size() == 0 && t.html != ''){
				phoneboxnotationview =1;
				$('.phoneboxnote').remove();
			}
			$('.phonebox').remove();
			$('body').append(t.html);
			$('body').find('.phonebox .name').html(t.phone_com_title);
			$('body').find('.phonebox .cb_time_left').html(t.phone_com_time);
			$('.phonebox').draggable();
			

			if($('.phoneboxnote').size() == 0 && phoneboxnotationview ==1){
				nxMain.ajaxRequest("/phones/hasclientnotes", {}, function(t) {
					$('.phoneboxnote').remove();
					$('body').append(t.html);
					$('body').find('.phoneboxnote .name').html(t.phone_note_title);
					$('body').find('.phoneboxnote .content').val(t.phone_note_text);
					if(t.phone_note_text == 'Notes impossibles.'){
						$('body').find('.phoneboxnote .content').prop('readonly', true);
					}else{
						$('body').find('.phoneboxnote .content').prop('readonly', false);
					}
					$('body').find('.phoneboxnote #phone_note_call').val(t.phone_note_call);
					$('body').find('.phoneboxnote #phonenoteagent').val(t.phone_note_agent);
					$('.phoneboxnote').draggable();
				});
			}
		})
    },
    initModals: function() {
        $(".nx_openinlightbox").unbind("click").click(function() {
            return nxMain.openUrlInModal($(this).attr("href")), !1
        }), $(".nx_openlightbox").unbind("click").click(function() {
            return nxMain.openModal($(this).attr("href"), $(this).attr("param")), !1
        })
    },
    initMenu: function() {
        $(window).scroll(function() {
            $(this).scrollTop() <= 50 ? $(".container_fixed").removeClass("fixed_effect") : $(".container_fixed").addClass("fixed_effect")
        }), $("#navigation ul .parent_title").unbind("hover").hover(function() {
            $(".sub_cat").hide(), $("span.parent_title").removeClass("selected"), $(this).parent("li").find(".sub_cat").each(function() {
                $(this).parent("li").find("span.parent_title").addClass("selected"), $(this).show()
            })
        }), $(".sub_cat").unbind("mouseleave").mouseleave(function() {
            $(this).hide(), $("span.parent_title").removeClass("selected")
        }), $("#track_header2").unbind("mouseleave").mouseleave(function() {
            $(".sub_cat").hide(), $("span.parent_title").removeClass("selected")
        })
    },
    initEmail: function() {
        $(".nx_emailbox").unbind("click").click(function() {
            var t = $(this).attr("href");
            return nxMain.ajaxRequest(t, {}, function(i) {
                i["return"] === !1 ? ($("#myModal").remove(), $("body").append(i.html), $("#myModal").modal({
                    backdrop: !0,
                    keyboard: !0,
                    show: !0
                })) : i["return"] === !0 && (document.location.href = t)
            }), !1
        })
    },
    initProductsLogin: function() {},
    initPhone: function() {
        $(".nx_phonebox").unbind("click").click(function() {
            if (undefined != $(this).attr("href")) var t = $(this).attr("href");
            else var t = $(this).find(".ae_phone_href").html();
            return nxMain.ajaxRequest(t, {
                id: $(this).find(".ae_phone_param").html()
            }, function(t) {
                t["return"] === !0 ? ($("#myModal").remove(), $("body").append(t.html), $("#myModal").modal({
                    backdrop: !0,
                    keyboard: !0,
                    show: !0
                })) : t["return"] === !1 && (void 0 !== t.msg && alert(t.msg), document.location.reload())
            }), !1
        })
    },
    initDebug: function() {
        $('<div id="debug_nx"></div>').appendTo("body")
    },
    refreshFilters: function() {
        if (this.debug) {
            var t = "filters:<br/>";
            for (i in nxMain.agentListFilters)
                if ("[object Array]" === Object.prototype.toString.call(nxMain.agentListFilters[i])) {
                    t += "--- " + i + ":<br/>";
                    for (j in nxMain.agentListFilters[i]) t += " ------ " + j + ": " + nxMain.agentListFilters[i][j] + "<br/>"
                } else t += "--- " + i + ":" + nxMain.agentListFilters[i] + "<br/>";
            $("#debug_nx").html(t)
        }
    },
    getFiltersPostDatas: function() {
        var t = new nxMain.cloneObject(nxMain.agentListFilters);
        t.ajax_for_agents = 1;
        var i = $("#numPage").val();
        return t.page = i, nxMain.debug && (t.debug = 1), t.term = $("form#filters_form input[name=sf_term]").val(), t.term_novalue == t.term && (t.term = ""), "" == t.term && "" != $("#filters_form_mobile #sf_term_mobile").val() && (t.term = $("#filters_form_mobile #sf_term_mobile").val()), t
    },
    eventsAgentListInit: function() {
        this.initModals(), this.initChat(), this.initEmail(), this.initPhone(), $(".nxtooltip").tooltip(), $("#agents_list .ae_presentation").click(function() {
            var t = $(this).parents(".ae_txts").find(".ae_pseudo a").attr("href");
            document.location.href = t
        }), $("#agents_list .aeb_audio a").click(function() {
            nxMain.showPresentation($(this).find(".agent_audio_url").html(), $(this).find(".agent_audio_audio").html(), $(this).find(".agent_audio_pseudo").html())
        })
    },
    showPresentation: function(t, i, e) {
        $("#myModal").remove(), nxMain.ajaxRequest(t, {
            audio: i,
            pseudo: e
        }, function(t) {
            $("body").append(t), $("#myModal").modal({
                backdrop: !0,
                keyboard: !0,
                show: !0
            }), $("#myModal").on("hidden.bs.modal", function() {
                $("#myModal").remove()
            })
        }, "html")
    },
    initChat: function() {
        $(".nx_chatbox").unbind("click").click(function() {
            return $("#myModal").modal("hide"), nxMain.ajaxRequest($(this).attr("href"), {}, function(t) {
                if (t["return"] === !1) switch (t.typeError) {
                    case "login":
                        $("#myModal").remove(), $("body").append(t.value), $("#myModal").modal({
                            backdrop: !0,
                            keyboard: !0,
                            show: !0
                        });
                        break;
                    case "noCustomer":
                    case "create":
                        alert(t.value);
                        break;
                    case "noCredit":
                    case "chat":
                        nxMain.openModal(t.value, t.param);
                        break;
                    case "missParam":
                    case "noAgent":
                        document.location.href = t.value
                } else t["return"] === !0 && void 0 !== t.session && nx_chat.init(t.url, t.session, t.otherUrl, t.lastIdMsg, t.lastIdEvent)
            }), !1
        })
    },
    initCategorySearch: function() {
        var t = $("form#filters_form"),
            i = $("form#filters_form_mobile");
        nxMain.agentListFilters.term_novalue = t.find("input[name=sf_term_novalue]").val(), nxMain.eventsAgentListInit(), t.find("input[name=sf_media]").change(function() {
            if ($(this).is(":checked") === !0) nxMain.agentListFilters.media.push($(this).val());
            else {
                var t = $(this).val();
                nxMain.agentListFilters.media.splice(nxMain.agentListFilters.media.indexOf(t), 1)
            }
            $("#numPage").attr("value", 1), nxMain.refreshFilters(), nxMain.callAjaxQuery(!0)
        }), i.find("#sf_orderby_mobile").change(function() {
            "phone" == $(this).val() || "email" == $(this).val() || "chat" == $(this).val() ? nxMain.agentListFilters.media.push($(this).val()) : nxMain.agentListFilters.orderby = $(this).val(), $("#numPage").attr("value", 1), nxMain.refreshFilters(), nxMain.callAjaxQuery(!0)
        }), t.find("#sf_orderby").change(function() {
            var t = $(this).attr("id").replace("sf_", "");
            "orderby" == t && "default" != $(this).val() && (nxMain.agentListFilters[t] = $(this).val()), nxMain.refreshFilters(), nxMain.callAjaxQuery(!0)
        }), t.find("#sf_filterby").change(function() {
            var t = $(this).attr("id").replace("sf_", "");
            nxMain.agentListFilters[t] = $(this).val(), $("#numPage").attr("value", 1), nxMain.refreshFilters(), nxMain.callAjaxQuery(!0)
        }), i.find("select").change(function() {
            var t = $(this).attr("id").replace("sf_", "").replace("_mobile", "");
            nxMain.agentListFilters[t] = $(this).val(), $("#numPage").attr("value", 1), nxMain.refreshFilters(), nxMain.callAjaxQuery(!0)
        }), $("form#filters_form").submit(function() {
            var i = t.find("input[name=sf_term]").val();
            return "" != nxMain.lastTerm || i != nxMain.agentListFilters.term_novalue && "" != i ? (nxMain.lastTerm = i, nxMain.agentListFilters.term = i, nxMain.refreshFilters(), $("#numPage").attr("value", 1), clearTimeout(nxMain.agentListTimer), nxMain.callAjaxQuery(!0), !1) : ($(".tooltip_noterm").tooltip("show"), setTimeout(function() {
                $(".tooltip_noterm").tooltip("hide")
            }, 2e3), !1)
        }), $("#filters_form_mobile").submit(function() {
            var t = i.find("#sf_term_mobile").val();
            return nxMain.lastTerm = t, nxMain.agentListFilters.term = t, nxMain.refreshFilters(), $("#numPage").attr("value", 1), clearTimeout(nxMain.agentListTimer), nxMain.callAjaxQuery(!0), !1
        })
    },
    initAgentListFilters: function() {
        var t = $("form#filters_form");
        t.find("input[name=sf_media]").each(function() {
            $(this).is(":checked") === !0 && nxMain.agentListFilters.media.push($(this).val())
        }), t.find("select").each(function() {
            var t = $(this).attr("id").replace("sf_", "");
            ("orderby" == t && "default" != $(this).val() || "filterby" == t && "allagents" != $(this).val()) && (nxMain.agentListFilters[t] = $(this).val())
        })
    },
    callAjaxQuery: function(t) {
        clearTimeout(nxMain.agentListTimer), void 0 != t && 1 == t && $("#search_filters .sf_counter").addClass("loading"), nxMain.ajaxRequest($("form#filters_form").attr("action"), nxMain.getFiltersPostDatas(), function(i) {
            $("#agents_list").html(i.html), $("#search_filters .sf_counter").html(i.count_html), $("#tuto").html(i.tuto), void 0 != t && 1 == t && $("#search_filters .sf_counter").removeClass("loading"), nxMain.autoRefresh && (nxMain.agentListTimer = setTimeout(function() {
                nxMain.ajaxUpdateAgentList(nxMain.agentListFilters.id_category)
            }, nxMain.agentListTimerRefreshInterval)), nxMain.eventsAgentListInit(), 0 == nxMain.hideScene && ("" == $("#tuto").html() ? ($("#cat_category").show(), $("#tuto").attr("style", "margin-top:0")) : ($("#cat_category").hide(), $("#tuto").attr("style", "margin-top:10px")))
        }, "json")
    },
    openModal: function(t, i) {
        var e = {};
        e = void 0 === i ? {
            isAjax: 1
        } : {
            param: i
        }, $("#myModal").remove(), this.ajaxRequest(t, e, function(t) {
            void 0 !== t.html ? ($("body").append(t.html), $("#myModal").modal({
                backdrop: !0,
                keyboard: !0,
                show: !0
            }), void 0 != t.chat && 1 == t.chat && nxMain.initChat()) : "usernovalid" === t["return"] && void 0 !== t.msg && alert(t.msg)
        }, "json")
    },
    openUrlInModal: function(t) {
        $("#myModal").remove(), this.ajaxRequest(t, [], function(t) {
            "usernovalid" === t["return"] && void 0 != t.msg || ($("body").append(nxMain.getTwitterModalHtmlTemplate(t.title, t.content, t.button)), $("#myModal").modal({
                backdrop: !0,
                keyboard: !0,
                show: !0
            }))
        }, "json")
    },
    modalLoading: function() {
        $("#myModal").remove();
        var t = '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">';
        t += '<div class="modal-dialog"><div class="modal-content"><div class="modal-header">', t += '<h4 class="modal-title" id="myModalLabel">' + title + "</h4>", t += "</div>", t += '<div class="modal-body">' + content + "</div>", t += "</div></div></div>", $("body").append(), $("#myModal").modal({
            backdrop: !0,
            keyboard: !1,
            show: !0
        })
    },
    initAgentList: function(t, i) {
        nxMain.agentListFilters.id_category = t, nxMain.agentListTimerRefreshInterval = i, nxMain.autoRefresh && (nxMain.agentListTimer = setTimeout(function() {
            nxMain.ajaxUpdateAgentList(t)
        }, nxMain.agentListTimerRefreshInterval, i))
    },
    ajaxUpdateAgentList: function(t) {
        nxMain.callAjaxQuery()
    },
    getTwitterModalHtmlTemplate: function(t, i, e) {
        var n = '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">';
        return n += '<div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>', n += '<h4 class="modal-title" id="myModalLabel">' + t + "</h4>", n += "</div>", n += '<div class="modal-body">' + i + "</div>", n += '<div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">' + e + "</button>", n += "</div></div></div></div>"
    },
    ajaxRequest: function(t, i, e, n) {
        void 0 == n && (n = "json"), $.ajax({
            type: "POST",
            dataType: n,
            url: t,
            data: i,
            success: function(t) {
                void 0 != e && e(t)
            }
        })
    },
    cloneObject: function(t) {
        for (i in t) "source" == typeof t[i] ? this[i] = new this.cloneObject(t[i]) : this[i] = t[i]
    },
    nxSelectify: function(t) {
        t.hide();
        var i = "nxselect_" + t.attr("id");
        $('<div id="' + i + '" class="nxselect_div"></div>').insertBefore(t);
        var e = '<div class="nxselect_selected"><span class="nxs_icon"></span> ' + t.find(":selected").html() + '</div><div class="nxselect_list">';
        t.parents("form").find("label[for=" + t.attr("id") + "]").addClass("nxselect_label"), void 0 !== t.parents("form").find("label[for=" + t.attr("id") + "]").html() && (e += '<div class="nxselect_title">' + t.parents("form").find("label[for=" + t.attr("id") + "]").html() + "</div>"), e += "<ul>", t.find("option").each(function(i) {
            var n = $(this).attr("icon");
            e += "<li " + (n ? 'hascustomicon="1"' : "") + ' rel="' + $(this).val() + '"' + ($(this).val() == t.find(":selected").val() ? ' class="nxli_selected"' : "") + '><i class="nxli_icon glyphicon' + (n ? " glyphicon-" + n : 0 == i ? " glyphicon-ok" : "") + '"></i>' + $(this).html() + "</li>"
        }), e += "</ul></div>", $("#" + i).html(e), this.nxSelectifyEvents(t, $("#" + i))
    },
    nxSelectOpen: function(t) {
        t.addClass("opened")
    },
    nxSelectClose: function(t) {
        t.removeClass("opened")
    },
    nxSelectSwitch: function(t) {
        t.hasClass("opened") ? nxMain.nxSelectClose(t) : nxMain.nxSelectOpen(t)
    },
    nxSelectifyEvents: function(t, i) {
        i.hover(function() {
            nxMain.nxSelectOpen($(this))
        }, function() {
            nxMain.nxSelectClose($(this))
        }), i.find("li").hover(function() {
            $(this).hasClass("nxli_selected") || 1 != !$(this).attr("hascustomicon") || $(this).find(".nxli_icon").addClass("glyphicon-ok"), $(this).find(".nxli_icon").css({
                opacity: .5
            })
        }, function() {
            $(this).hasClass("nxli_selected") || 1 != !$(this).attr("hascustomicon") || $(this).find(".nxli_icon").removeClass("glyphicon-ok"), $(this).find(".nxli_icon").css({
                opacity: 1
            })
        }), $("label.nxselect_label").unbind("click").click(function() {
            nxMain.nxSelectSwitch($("div#nxselect_" + $(this).attr("for")))
        }), i.find("li").click(function() {
            i.find("li").removeClass("nxli_selected"), $(this).addClass("nxli_selected"), i.find(".nxli_icon").removeClass("glyphicon-ok"), 1 == !$(this).attr("hascustomicon") && $(this).find(".nxli_icon").addClass("glyphicon-ok"), t.val($(this).attr("rel")), t.change(), i.find(".nxselect_selected").html('<span class="nxs_icon"></span>' + t.find('option[value="' + $(this).attr("rel") + '"]').html())
        })
    }
};
$(document).ready(function() {
    nxMain.init(), nxMain.initAgentList(1, 8e3)
}), $(document).ready(function() {
    $.cookieBar(), $(".show_hide").show(), $(".hide_btn").css("display", "none"), $(".show_hide").click(function() {
        $(".slidingDiv").slideToggle("fast", function() {
            "none" == $(".slidingDiv").css("display") ? ($(".hide_btn").css("display", "none"), $(".show_btn").css("display", "block")) : ($(".hide_btn").css("display", "block"), $(".show_btn").css("display", "none"))
        })
    }), $(".nav_categories").on("click", "a", function() {
        $(".nav_categories").find(".active").removeClass("active")
    }), $("body").on("DOMNodeInserted", function(t) {
        $(t.target).is(".chatbox_agent") && ($.playSound("http://www.spiriteo.fr/media/sonnerie/0159"), document.getElementById("audiosonnerie").play())
    })
	
	$(document).on("click", ".phonebox .cb_notes", function() {	
		nxMain.ajaxRequest("/phones/hasclientnotes", {}, function(t) {
			$('.phoneboxnote').remove();
			$('body').append(t.html);
			$('body').find('.phoneboxnote .name').html(t.phone_note_title);
			$('body').find('.phoneboxnote .content').val(t.phone_note_text);
			$('body').find('.phoneboxnote #phone_note_call').val(t.phone_note_call);
			$('body').find('.phoneboxnote #phone_note_tchat').val(t.phone_note_tchat);
			$('body').find('.phoneboxnote #phonenoteagent').val(t.phone_note_agent);
			$('.phoneboxnote').draggable();
		});
		phoneboxnotationview = 1;
	});
	$(document).on("click", ".chatbox .cb_notes", function() {	
		nxMain.ajaxRequest("/phones/hasclientnotes", {}, function(t) {
			$('.phoneboxnote').remove();
			$('body').append(t.html);
			$('body').find('.phoneboxnote .name').html(t.phone_note_title);
			$('body').find('.phoneboxnote .content').val(t.phone_note_text);
			$('body').find('.phoneboxnote #phone_note_call').val(t.phone_note_call);
			$('body').find('.phoneboxnote #phone_note_tchat').val(t.phone_note_tchat);
			$('body').find('.phoneboxnote #phonenoteagent').val(t.phone_note_agent);
			//$('.phoneboxnote').css('left','20px');
			$('.phoneboxnote').draggable();
		});
		phoneboxnotationview = 1;
	});
	
	$(document).on("click", ".phoneboxnote .cb_close", function() {	
		nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesHasclientnotesForm .content').val(),call:$('#NotesHasclientnotesForm #phone_note_call').val(),tchat:$('#NotesHasclientnotesForm #phone_note_tchat').val(),agent:$('#NotesHasclientnotesForm #phonenoteagent').val()}, function(t) {
					
			});
		 $('.phoneboxnote').remove();
		 phoneboxnotationview = 0;
	});
	
	$(document).on("click", "#NotesHasclientnotesForm .btn", function() {	

		  nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesHasclientnotesForm .content').val(),call:$('#NotesHasclientnotesForm #phone_note_call').val(),tchat:$('#NotesHasclientnotesForm #phone_note_tchat').val(),agent:$('#NotesHasclientnotesForm #phonenoteagent').val()}, function(t) {
					
			});
	});
	
	$(document).on("change", "#NotesHasclientnotesForm .content", function() {	

		  nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesHasclientnotesForm .content').val(),call:$('#NotesHasclientnotesForm #phone_note_call').val(),tchat:$('#NotesHasclientnotesForm #phone_note_tchat').val(),agent:$('#NotesHasclientnotesForm #phonenoteagent').val()}, function(t) {
					
			});
	});
	
	$(document).on("click", "#NotesShowclientnotesForm .btn", function() {	

		  nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesShowclientnotesForm .content').val(),call:$('#NotesShowclientnotesForm #phone_note_call').val(),tchat:$('#NotesShowclientnotesForm #phone_note_tchat').val(),agent:$('#NotesShowclientnotesForm #phonenoteagent').val()}, function(t) {
					
			});
	});
	
	$(document).on("change", "#NotesShowclientnotesForm .content", function() {	

		  nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesShowclientnotesForm .content').val(),call:$('#NotesShowclientnotesForm #phone_note_call').val(),tchat:$('#NotesShowclientnotesForm #phone_note_tchat').val(),agent:$('#NotesShowclientnotesForm #phonenoteagent').val()}, function(t) {
					
			});
	});
	
	$(document).on("click", "#NotesGetTemplateChatForm .btn", function() {	

		  nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesGetTemplateChatForm .content').val(),call:$('#NotesGetTemplateChatForm #phone_note_call').val(),tchat:$('#NotesGetTemplateChatForm #phone_note_tchat').val(),agent:$('#NotesGetTemplateChatForm #phonenoteagent').val()}, function(t) {
					
			});
	});
	
	$(document).on("change", "#NotesGetTemplateChatForm .content", function() {	

		  nxMain.ajaxRequest("/phones/addclientnotes", {note:$('#NotesGetTemplateChatForm .content').val(),call:$('#NotesGetTemplateChatForm #phone_note_call').val(),tchat:$('#NotesGetTemplateChatForm #phone_note_tchat').val(),agent:$('#NotesGetTemplateChatForm #phonenoteagent').val()}, function(t) {
					
			});
	});
	
	$(document).on("click", ".phonenote_edit", function() {	
		nxMain.ajaxRequest("/phones/showclientnotes", {note:$(this).attr('rel')}, function(t) {
			phoneboxnotationview =1;
			$('.phoneboxnote').remove();
			$('body').append(t.html);
			$('body').find('.phoneboxnote .name').html(t.phone_note_title);
			$('body').find('.phoneboxnote .content').val(t.phone_note_text);
			$('body').find('.phoneboxnote #phone_note_call').val(t.phone_note_call);
			$('body').find('.phoneboxnote #phone_note_tchat').val(t.phone_note_tchat);
			$('body').find('.phoneboxnote #phonenoteagent').val(t.phone_note_agent);
			$('.phoneboxnote').draggable();
		});
	});
	
});
