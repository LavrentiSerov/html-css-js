$(document).ready(function(){


  new WOW().init();

  jQuery(window).load(function() { 
    jQuery("#preloader").delay(100).fadeOut("slow");
    jQuery("#load").delay(100).fadeOut("slow");
  });


  //jQuery to collapse the navbar on scroll
  // $(window).scroll(function() {
  //  if ($(".navbar").offset().top > 50) {
  //    $(".navbar-fixed-top").addClass("top-nav-collapse");
  //  } else {
  //    $(".navbar-fixed-top").removeClass("top-nav-collapse");
  //  }
  // });

  //backToTop

  $('body').append('<div id="toTop" class="btn"><span class="glyphicon glyphicon-chevron-up"></span></div>');
      $(window).scroll(function () {
      if ($(this).scrollTop() != 0) {
        $('#toTop').fadeIn();
      } else {
        $('#toTop').fadeOut();
      }
    }); 
    $('#toTop').click(function(){
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });

if($(window).width() >= 767){
    $(".mega-dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            // $(this).toggleClass('open'); 
            $(this).addClass('active');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            // $(this).toggleClass('open');
            $(this).removeClass('active');         
        }
    );
  }

    $('[data-toggle="tooltip"]').tooltip();

    //carousel
     $("#carousel").carousel({
         interval : 6000,
         // pause: true
     });

     //fade-quote-carousel
     //carousel
     $("#fade-quote-carousel").carousel({
         interval : 5000,
         //pause: false
     });

    $('.filter-advance').click(function(e) {
      $(e.target).find('.fa-plus-circle, .fa-minus-circle').toggleClass("fa-plus-circle fa-minus-circle");
  });

    $('.search a').click(function(){
      $(this).toggleClass("active-search");
  });



    //user-logged dropdown
    // $(".user-logged").hover(            
    //     function() {
    //         $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
    //         $(this).toggleClass('open');        
    //     },
    //     function() {
    //         $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
    //         $(this).toggleClass('open');       
    //     }
    // );

    $('.collapse').on('shown.bs.collapse', function(){
  $(this).parent().find(".fa-sort-asc").removeClass("fa-sort-asc").addClass("fa-sort-desc");
  }).on('hidden.bs.collapse', function(){
  $(this).parent().find(".fa-sort-desc").removeClass("fa-sort-desc").addClass("fa-sort-asc");
  });

/**message Collapse**/

      $('.collapse').on('shown.bs.collapse', function(){
  $(this).parent().find(".fa-plus-circle").removeClass("fa-plus-circle").addClass("fa-minus-circle");
  }).on('hidden.bs.collapse', function(){
  $(this).parent().find(".fa-minus-circle").removeClass("fa-minus-circle").addClass("fa-plus-circle");
  });





    // Collapse accordion every time dropdown is shown
$('.dropdown-accordion').on('show.bs.dropdown', function (event) {
  var accordion = $(this).find($(this).data('accordion'));
  accordion.find('.panel-collapse.in').collapse('hide');
});

// Prevent dropdown to be closed when we click on an accordion link
$('.dropdown-accordion').on('click', 'a[data-toggle="collapse"]', function (event) {
  event.preventDefault();
  event.stopPropagation();
  $($(this).data('parent')).find('.panel-collapse.in').collapse('hide');
  $($(this).attr('href')).collapse('show');
})



//nav-tabs scroll

    $('a.scroll[href^="#"]').bind('click.smoothscroll',function (e) {
        e.preventDefault();
        var target = this.hash,
        $target = $(target);

        $('html, body').stop().animate( {
            'scrollTop': $target.offset().top-100
        }, 900, 'swing', function () {
            window.location.hash = target;
        } );
    } );




  //header-color

    $(window).scroll(function() {
        var scroll = $(window).scrollTop();

        if (scroll >= 85) {
             $(".navbar").addClass("darkHeader");
        } else {
             $(".navbar").removeClass("darkHeader");
        }
    });



    
//event div toogle

$('.event-box').find('a.expand').on('click', function (e) { //[href="#"]
    e.preventDefault();
    this.expand = !this.expand;
    $(this).text(this.expand?"Cerrar":"Continuar leyendo");
    $(this).closest('.event-box').find('.small-div, .big-div').toggleClass('small-div big-div');
});
  

});
